import React, { useState, useEffect, useRef } from 'react';
import { Egg } from 'lucide-react';

function App() {
  const [eggPosition, setEggPosition] = useState({ x: 50, y: 50 });
  const [velocity, setVelocity] = useState({ x: 0, y: 1 }); // Start with a small downward velocity
  const [gravity, setGravity] = useState(0.2); // Reduced gravity for slower falling
  const [isGameOver, setIsGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const gameAreaRef = useRef<HTMLDivElement>(null);
  const animationFrameRef = useRef<number>();
  const velocityRef = useRef(velocity);

  // Keep velocityRef in sync with velocity state
  useEffect(() => {
    velocityRef.current = velocity;
  }, [velocity]);

  // Initialize the game
  useEffect(() => {
    startGame();
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, []);

  // Reset game state
  const startGame = () => {
    setEggPosition({ x: 50, y: 50 });
    setVelocity({ x: 0, y: 1 }); // Start with a small downward velocity
    velocityRef.current = { x: 0, y: 1 };
    setIsGameOver(false);
    setScore(0);
    animationFrameRef.current = requestAnimationFrame(gameLoop);
  };

  // Main game loop
  const gameLoop = () => {
    if (isGameOver) return;

    // Update velocity with gravity directly using ref
    velocityRef.current = {
      ...velocityRef.current,
      y: velocityRef.current.y + gravity
    };

    // Update position based on velocity
    setEggPosition(prev => {
      const gameArea = gameAreaRef.current;
      if (!gameArea) return prev;

      const gameWidth = gameArea.clientWidth;
      const gameHeight = gameArea.clientHeight;
      
      let newX = prev.x + velocityRef.current.x;
      let newY = prev.y + velocityRef.current.y;
      
      // Bounce off walls
      if (newX <= 0 || newX >= gameWidth - 40) {
        velocityRef.current = {
          ...velocityRef.current,
          x: -velocityRef.current.x
        };
        newX = newX <= 0 ? 0 : gameWidth - 40;
      }
      
      // Check if egg hit the ground
      if (newY >= gameHeight - 40) {
        setIsGameOver(true);
        return prev;
      }
      
      // Check if egg hit the ceiling - game over
      if (newY <= 0) {
        setIsGameOver(true);
        return prev;
      }
      
      return { x: newX, y: newY };
    });
    
    // Continue the game loop
    animationFrameRef.current = requestAnimationFrame(gameLoop);
  };

  // Handle click to make the egg fly
  const handleClick = () => {
    if (isGameOver) {
      startGame();
      return;
    }
    
    // Boost the egg upward (reduced boost for better control)
    velocityRef.current = {
      ...velocityRef.current,
      y: -7 // Reduced upward boost for better control
    };
    
    setScore(prev => prev + 1);
  };

  return (
    <div 
      className="min-h-screen bg-gradient-to-b from-sky-300 to-sky-500 flex flex-col items-center justify-center relative overflow-hidden"
      onClick={handleClick}
    >
      <div className="absolute top-4 left-4 bg-white/80 p-2 rounded-lg shadow-md z-10">
        <p className="text-xl font-bold">ניקוד: {score}</p>
      </div>
      
      <div 
        ref={gameAreaRef}
        className="w-full max-w-lg h-[70vh] bg-sky-100/50 rounded-lg border-4 border-white/50 shadow-xl relative"
      >
        {/* Ceiling with spikes */}
        <div className="absolute top-0 w-full h-4 bg-gradient-to-r from-gray-700 to-gray-500 flex">
          {Array.from({ length: 20 }).map((_, i) => (
            <div key={i} className="h-4 w-4 bg-gray-800" style={{ clipPath: 'polygon(50% 100%, 0 0, 100% 0)' }}></div>
          ))}
        </div>
        
        {/* Flying Egg */}
        <div 
          className="absolute"
          style={{ 
            left: `${eggPosition.x}px`, 
            top: `${eggPosition.y}px`,
            width: '40px',
            height: '40px'
          }}
        >
          <Egg size={40} className="text-white fill-yellow-100 drop-shadow-lg" strokeWidth={2} />
        </div>
        
        {/* Ground */}
        <div className="absolute bottom-0 w-full h-8 bg-gradient-to-r from-green-700 to-green-500"></div>
        
        {/* Game Over Screen */}
        {isGameOver && (
          <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center">
            <h2 className="text-3xl font-bold text-white mb-4">המשחק נגמר!</h2>
            <p className="text-xl text-white mb-6">הניקוד שלך: {score}</p>
            <button 
              onClick={(e) => {
                e.stopPropagation();
                startGame();
              }}
              className="bg-yellow-400 hover:bg-yellow-500 text-black font-bold py-2 px-6 rounded-full shadow-lg transition-colors"
            >
              שחק שוב
            </button>
          </div>
        )}
      </div>
      
      <div className="mt-6 bg-white/80 p-4 rounded-lg shadow-md max-w-md text-right">
        <h2 className="text-xl font-bold mb-2">הוראות:</h2>
        <p className="mb-2">לחץ על המסך כדי לגרום לביצה לעוף למעלה</p>
        <p className="mb-2">אל תיתן לביצה ליפול לקרקע!</p>
        <p>אל תיתן לביצה לגעת בתקרה!</p>
      </div>
    </div>
  );
}

export default App;